echo "Hello from tftp script"
